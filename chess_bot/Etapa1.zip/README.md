# Rulare
`make xboard` -- compileaza sursele si deschide engine-ul in xboard (comanda suficienta)
`make build` -- compileaza sursele  
`make clean` -- curata folderul de fisierele create in urma compilarii  

# Structura proiectului
__main.cpp__ contine consola prin intermediul caruia programul comunica cu protocolul xboard  
__functions.cpp__ contine functii utile pentru reprezentarea in intermediul programului a tablei de sah si pentru generarea miscarii pionilor  
__functions.h__ contine definitiile functiilor anterior descrise  
__variables.cpp__ contine variabile globale ce vor fi folosite in restul surselor si sunt reprezintate in acest moment de reprezentarea tablei sub forma de vector, culoarea curenta si culoarea cu care joaca engine-ul  
__variables.h__ contine definitiile variabilelor anterior descrise  
__definitions.h__ contine definitii pentru reprezentarea culorilor, pieselor si a tablei de sah  

# Abordarea algoritmica
"greedy": se cauta primul pion ce poate fi mutat de catre culoarea cu care joaca engine-ul si va fi mutat pe diagonala in cazul in care poate lua o piesa adversa, in fata cu 2 patratele daca se afla in pozitia initiala sau cu un patratel. 
Complexitate: O(n) , n = marimea tablei de sah, intrucat se va cauta pe toata tabla un pion ce poate fi mutat

# Surse de inspiratie
Playlist YT: https://www.youtube.com/playlist?list=PLZ1QII7yudbc-Ky058TEaOstZHVbT-2hg  
-- idee despre reprezentarea tablei de sah sub forma a doi vectori, unul pentru piesele de sah si unul pentru culorile acestora

# Responsabilitati membrii
Toti membrii echipei au contribuit fie la conectarea engine-ului la xboard, generarea miscarii pionilor, formatarea codului, cautarea unor resurse, fixarea bug-urilor scrise de ceilalti membrii ai echipei 