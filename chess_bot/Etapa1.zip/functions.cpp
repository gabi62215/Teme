#include <cstdio>
#include <cstdlib>
#include "variables.h"
#include "definitions.h"
#include "functions.h"

/*
    Function which initializes the board
*/
void init_board() {
    for(int i = 0; i < 64; i++) {
        color[i] = init_color[i];
        piece[i] = init_piece[i];
    }
    side = WHITE;
    engine_side = BLACK;
}

/*
    Function which translates a move from the internal coding (2 ints)
    to something that can be printed out to xboard (char *)
*/
char *moveStringFromInt(int from, int to) {
    if (from < 0 || from >= 64 || to < 0 || to >= 64)
        return nullptr;
    char *result = (char *) (malloc(5 * sizeof(char)));
    result[0] = from % 8 + 'a';
    result[1] = 8 - from / 8 + '0';
    result[2] = to % 8 + 'a';
    result[3] = 8 - to / 8 + '0';
    return result;
}

/*
    Function which receives a move in the format that xboard works with
    and makes the internal chess board update
*/
int registerMove(char *s) {
    if (s[0] < 'a' || s[0] > 'h' ||
        s[1] < '0' || s[1] > '9' ||
        s[2] < 'a' || s[2] > 'h' ||
        s[3] < '0' || s[3] > '9') {
        return -1;
    }

    // conversion from char* format to 2 ints
    int from, to;
    from = s[0] - 'a';
    from += 8 * (8 - (s[1] - '0'));
    to = s[2] - 'a';
    to += 8 * (8 - (s[3] - '0'));
    if (piece[from] == EMPTY || color[from] == EMPTY){
        return -1;
    }

    piece[to] = piece[from];
    color[to] = color[from];
    if(piece[from] == PAWN && s[3] == '8'){
        piece[to] = QUEEN;
    }

    piece[from] = EMPTY;
    color[from] = EMPTY;
    return 1;
}

/*
    Function that decides how to move pawns
*/
const char *movePawn() {
    if (side == BLACK) {
        for (int i = 0; i < 64; i++) {
            if (piece[i] == PAWN && color[i] == side) {
                if(i + 7 < 64 && color[i + 7] == WHITE && (i + 7) / 8 == (i + 8) / 8) {
                    // black pawn captures to its right
                    registerMove(moveStringFromInt(i, i + 7));
                    return moveStringFromInt(i, i + 7);
                }
                if(i + 9 < 64 && color[i + 9] == WHITE && (i + 9) / 8 == (i + 8) / 8) {
                    // black pawn captures to its left
                    registerMove(moveStringFromInt(i, i + 9));
                    return moveStringFromInt(i, i + 9);
                }
                if (i + 16 < 64 && piece[i + 16] == EMPTY && piece[i] == init_piece[i] && piece[i + 8] == EMPTY) {
                    // black pawn initial 2 steps forward, no capture
                    registerMove(moveStringFromInt(i, i + 16));
                    return moveStringFromInt(i, i + 16);
                }
                if (i + 8 < 64 && piece[i + 8] == EMPTY) {
                    // black pawn moves one space forward, no capture
                    registerMove(moveStringFromInt(i, i + 8));
                    return moveStringFromInt(i, i + 8);
                }
            }
        }
    }

    else if (side == WHITE) {
        for (int i = 0; i < 64; i++) {
            if (piece[i] == PAWN && color[i] == side) {
                if(i - 9 < 64 && color[i - 9] == BLACK && (i - 9) / 8 == (i - 8) / 8) {
                    // white pawn captures to its left
                    registerMove(moveStringFromInt(i, i - 9));
                    return moveStringFromInt(i, i - 9);
                }
                if(i - 7 < 64 && color[i - 7] == BLACK && (i - 7) / 8 == (i - 8) / 8) {
                    // white pawn captures to its right
                    registerMove(moveStringFromInt(i, i - 7));
                    return moveStringFromInt(i, i - 7);
                }
                if (i - 16 > 0 && piece[i - 16] == EMPTY && piece[i] == init_piece[i] && piece[i - 8] == EMPTY) {
                    // whitepawn initial 2 steps forward, no capture
                    registerMove(moveStringFromInt(i, i - 16));
                    return moveStringFromInt(i, i - 16);
                }
                if (i - 8 >= 0 && piece[i - 8] == EMPTY) {
                    // white pawn moves one space forward, no capture
                    registerMove(moveStringFromInt(i, i - 8));
                    return moveStringFromInt(i, i - 8);
                }
            }
        }
    }

    return NULL;
}

/*
    Function which prints the chessboard if needed
*/
void printTable(){
    for(int i = 0; i < 64; i++){
        printf("%d ", piece[i]);
        if((i+1) % 8 == 0)
            printf("\n");
    }
}