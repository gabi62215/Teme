#ifndef PROIECT_FUNCTIONS_H
#define PROIECT_FUNCTIONS_H

void init_board();
char *moveStringFromInt(int from, int to);
int registerMove(char *s);
const char *movePawn();
void printTable();

#endif //PROIECT_FUNCTIONS_H
