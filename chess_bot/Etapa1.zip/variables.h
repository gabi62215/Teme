#ifndef PROIECT_VARIABLES_H
#define PROIECT_VARIABLES_H

/* Global variables definitions to use in any source file */

/* Board representation */
extern int color[64];
extern int piece[64];
extern int init_color[64];
extern int init_piece[64];


extern int side;
extern int engine_side;

#endif //PROIECT_VARIABLES_H
