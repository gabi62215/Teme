package com.company;

public interface Builder {
    void setId(int id);
    void setName(String nume);
    void setPretMinim(String pret);
    void setAn(String an);
    void setCaracteristica1(String c1);
    void setCaracteristica2(String c2);

}
