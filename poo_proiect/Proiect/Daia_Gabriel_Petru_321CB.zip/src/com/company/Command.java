package com.company;

public interface Command {
    void execute();
}
